
1. get cquotes working - we need an app that relies on IDCS for authentication

2. create a WAR that is a SAML IdP
    - 85% done. You need to update it to get the config properly as in the example fido code

3. Setup IDCS to be a SAML SP to your new IdP code

    https://confluence.oraclecorp.com/confluence/display/ATEAMIDCS/IDCS+SAML+Integration+with+Fido+Server

4. add the Daon stuff to #2
   - currently we prompt for username
    - you need to write the JSP that does all the other crap
    - and then savethe username in the J2EE session
    - and when done send the user to afteruserauthenticated.jsp
        == NOTE: you will need to do some more work to make this secure!

5. refactor the code to get rid of "com.oracle.fido" package name



IDCS as SP configuration details

assertionconsumerurl=http://tenant1.idcs.internal.oracle.com:8990/fed/v1/sp/sso
SAMLRecipient=http://tenant1.idcs.internal.oracle.com:8990/fed/v1/sp/sso
SAMLAudience=http://den00acm.us.oracle.com:8990/fed/TENANT1
SAMLIssuer=https://fido.example.com/fidoserver

SAML IDP signing keystore

keystorefile=certs/fidokeystore.jks
keystorepassword=Oracle1234
certificatealias=1




Provider ID https://idcs-08c29ed55e7b4fc9964a4efb2a1063c3.identity-test.oraclecloud.com/fed
Assertion Consumer Service URL https://idcs-08c29ed55e7b4fc9964a4efb2a1063c3.identity.oraclecloud.com/fed/v1/sp/sso
Logout Service Endpoint URL https://idcs-08c29ed55e7b4fc9964a4efb2a1063c3.identity.oraclecloud.com/fed/v1/sp/slo
Logout Service Return URL https://idcs-08c29ed55e7b4fc9964a4efb2a1063c3.identity.oraclecloud.com/fed/v1/sp/slo