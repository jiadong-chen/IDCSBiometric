package com.oracle.demoidp;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class IDPConfiguration {
	private static IDPConfiguration idpConfiguration = null;
	private Properties idpProperties;
	public static IDPConfiguration getIdpConfiguration(){
		if(idpConfiguration==null){
			idpConfiguration = new IDPConfiguration();
		}
		return idpConfiguration;
	}
	
	public String getIDCSACSUrl(){
		return this.getProperty("assertionconsumerurl");
	}
	
	private IDPConfiguration(){
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream stream = classLoader.getResourceAsStream("idp.properties");
		
		idpProperties = new Properties();
		try{
			idpProperties.load(stream);
		}
		catch(IOException ioe){
			System.out.println("Cannot read configuration properties file");
		}

	}
	
	public String getUserStorageConfiguration(){
		return this.getProperty("userStorage");
	}
	
	public String getApplicationID(){
		return this.getProperty("applicationID");
	}
	
	public String getProperty(String property){
		return idpProperties.getProperty(property);
	}
}
