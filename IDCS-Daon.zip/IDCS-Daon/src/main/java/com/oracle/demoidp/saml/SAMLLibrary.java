package com.oracle.demoidp.saml;

import com.oracle.demoidp.saml.SAML;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.KeyStore.PrivateKeyEntry;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.signature.XMLSignature;
import org.joda.time.DateTime;
import org.opensaml.Configuration;
import org.opensaml.common.impl.RandomIdentifierGenerator;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Audience;
import org.opensaml.saml2.core.AudienceRestriction;
import org.opensaml.saml2.core.AuthnContext;
import org.opensaml.saml2.core.AuthnContextClassRef;
import org.opensaml.saml2.core.AuthnRequest;
import org.opensaml.saml2.core.AuthnStatement;
import org.opensaml.saml2.core.Conditions;
import org.opensaml.saml2.core.Issuer;
import org.opensaml.saml2.core.NameID;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.Status;
import org.opensaml.saml2.core.StatusCode;
import org.opensaml.saml2.core.Subject;
import org.opensaml.saml2.core.SubjectConfirmation;
import org.opensaml.saml2.core.SubjectConfirmationData;
import org.opensaml.saml2.core.impl.AssertionMarshaller;
import org.opensaml.saml2.core.impl.AudienceBuilder;
import org.opensaml.saml2.core.impl.AudienceRestrictionBuilder;
import org.opensaml.saml2.core.impl.SubjectConfirmationBuilder;
import org.opensaml.saml2.core.impl.SubjectConfirmationDataBuilder;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.XMLObjectBuilderFactory;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.io.UnmarshallerFactory;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.security.SecurityHelper;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.keyinfo.KeyInfoGenerator;
import org.opensaml.xml.security.keyinfo.KeyInfoGeneratorFactory;
import org.opensaml.xml.security.keyinfo.KeyInfoGeneratorManager;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.security.x509.X509KeyInfoGeneratorFactory;
import org.opensaml.xml.signature.KeyInfo;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.signature.SignatureException;
import org.opensaml.xml.signature.Signer;
import org.opensaml.xml.signature.impl.SignatureBuilder;
import org.opensaml.xml.util.Base64;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import com.oracle.demoidp.IDPConfiguration;
import com.oracle.demoidp.IDPConfiguration;
import com.oracle.demoidp.util.U2fB64Encoding;

public class SAMLLibrary extends SAML {

    private static SAMLLibrary samlLibrary = null;

    final static String password = IDPConfiguration.getIdpConfiguration().getProperty("keystorepassword");
    final static String certificateAliasName = IDPConfiguration.getIdpConfiguration().getProperty("certificatealias");
    final static String fileName = IDPConfiguration.getIdpConfiguration().getProperty("keystorefile");

    private KeyStore keystore;
    private PrivateKeyEntry pkEntry;
    private PrivateKey pk;
    private X509Certificate cert;
    private BasicX509Credential credential;
    private Credential signingCredential;
    private Signature signature;
    javax.xml.crypto.dsig.XMLSignature xmlSignature;
    private Credential peerCredential;
    private KeyInfo serviceKeyInfo;
    private XMLSignatureFactory factory;
    private javax.xml.crypto.dsig.keyinfo.KeyInfo keyInfo;

    public static SAMLLibrary getSAMLLibrary() {
        if (samlLibrary == null) {
            samlLibrary = new SAMLLibrary();
        }
        return samlLibrary;
    }

    private SAMLLibrary() {
        char[] keystorePassword = this.password.toCharArray();
        try {
            keystore = KeyStore.getInstance(KeyStore.getDefaultType());
        } catch (KeyStoreException kse) {
            kse.printStackTrace();
        }

        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        InputStream stream = classLoader.getResourceAsStream(fileName);

        try {
            keystore.load(stream, keystorePassword);
            stream.close();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            //pkEntry = (KeyStore.PrivateKeyEntry)keystore.getEntry(SAMLLibrary.certificateAliasName,new KeyStore.PasswordProtection(keystorePassword));
            pkEntry = (KeyStore.PrivateKeyEntry) keystore.getEntry(SAMLLibrary.certificateAliasName, new KeyStore.PasswordProtection(keystorePassword));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnrecoverableEntryException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        }

        String providerName = System.getProperty("jsr105Provider", "org.jcp.xml.dsig.internal.dom.XMLDSigRI");
        try {
            factory = XMLSignatureFactory.getInstance("DOM",
                    (Provider) Class.forName(providerName).newInstance());
        } catch (Exception e) {
            e.printStackTrace();
        }

        KeyPair keyPair = new KeyPair(pkEntry.getCertificate().getPublicKey(), pkEntry.getPrivateKey());
        KeyInfoFactory kFactory = factory.getKeyInfoFactory();
        keyInfo = kFactory.newKeyInfo(Collections.singletonList(kFactory.newX509Data(Collections.singletonList(pkEntry.getCertificate()))));

        pk = pkEntry.getPrivateKey();
        cert = (X509Certificate) pkEntry.getCertificate();
        credential = new BasicX509Credential();
        credential.setEntityCertificate(cert);
        credential.setPrivateKey(pk);
        signingCredential = credential;
    }

    public void initializeSigning() {
        signature = null;
        SignatureBuilder signatureBuilder = (SignatureBuilder) Configuration.getBuilderFactory().getBuilder(Signature.DEFAULT_ELEMENT_NAME);
        signature = signatureBuilder.buildObject();
        //signature = (Signature)Configuration.getBuilderFactory().getBuilder(Signature.DEFAULT_ELEMENT_NAME).buildObject();
        signature.setSigningCredential(signingCredential);

        signature.setCanonicalizationAlgorithm(Canonicalizer.ALGO_ID_C14N_EXCL_OMIT_COMMENTS);
        signature.setSignatureAlgorithm(XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA1);

        peerCredential = SecurityHelper.getSimpleCredential(cert, null);

        X509KeyInfoGeneratorFactory x509KeyInfoGeneratorFactory = new X509KeyInfoGeneratorFactory();
        x509KeyInfoGeneratorFactory.setEmitEntityCertificate(true);

        KeyInfoGeneratorManager keyInfoGeneratorManager = new KeyInfoGeneratorManager();
        keyInfoGeneratorManager.registerFactory(x509KeyInfoGeneratorFactory);

        KeyInfoGeneratorFactory keyInfoGeneratorFactory = keyInfoGeneratorManager.getFactory(peerCredential);
        KeyInfoGenerator keyInfoGenerator = keyInfoGeneratorFactory.newInstance();
        try {
            serviceKeyInfo = keyInfoGenerator.generate(credential);
        } catch (org.opensaml.xml.security.SecurityException e) {
            e.printStackTrace();
        }
        signature.setKeyInfo(serviceKeyInfo);
    }

    public String getEncodedAssertion(String assertion) {
        String encodedAssertion = null;
        try {
            byte[] assertionBytes = assertion.getBytes("UTF-8");
            encodedAssertion = Base64.encodeBytes(assertionBytes, Base64.DONT_BREAK_LINES);
            //urlEncodedAssertion = URLEncoder.encode(encodedAssertion,"UTF-8");
        } catch (UnsupportedEncodingException uee) {
            uee.printStackTrace();
        }
        return encodedAssertion;
    }

    public String parseSAMLRequest(String encodedSAMLRequest) {
        String requestID = null;
        //String urlDecodedSAMLRequest = URLDecoder.decode(encodedSAMLRequest);
        encodedSAMLRequest = encodedSAMLRequest.replaceAll("\\r\\n", "");
        byte[] samlRequest = Base64.decode(encodedSAMLRequest);

        try {
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            documentBuilderFactory.setNamespaceAware(true);
            DocumentBuilder docBuilder = documentBuilderFactory.newDocumentBuilder();

            Document document = docBuilder.parse(new ByteArrayInputStream(samlRequest));
            Element element = document.getDocumentElement();

            UnmarshallerFactory unmarshallerFactory = Configuration.getUnmarshallerFactory();
            Unmarshaller unmarshaller = unmarshallerFactory.getUnmarshaller(element);
            XMLObject requestXmlObj = unmarshaller.unmarshall(element);
            AuthnRequest request = (AuthnRequest) requestXmlObj;
            requestID = request.getID();
            System.out.println("RequestId is: " + requestID);
        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (UnmarshallingException ume) {
            ume.printStackTrace();
        } catch (SAXException saxe) {
            saxe.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return requestID;
    }

    public String getURLEncodedAssertion(String assertion) {
        String encodedAssertion = getEncodedAssertion(assertion);
        String urlEncodedAssertion = null;
        try {
            urlEncodedAssertion = URLEncoder.encode(encodedAssertion, "UTF-8");
        } catch (UnsupportedEncodingException uee) {
            uee.printStackTrace();
        }
        return urlEncodedAssertion;
    }

    public static void main(String args[]) {
        SAMLLibrary library = SAMLLibrary.getSAMLLibrary();
        String assertion = library.getSAMLAssertion("kiranthakkar", "id-SAMLRequestID");
        System.out.println("Assertion for the user kiranthakkar: " + assertion);
        /*String encodedAssertion = library.getEncodedAssertion(assertion);
         String urlEncodedAssertion = library.getURLEncodedAssertion(assertion);
         System.out.println("Encoded assertion is: " + encodedAssertion);
         System.out.println("URLEncoded assertion is: " + urlEncodedAssertion);*/
        //String requestID = library.parseSAMLRequest("PHNhbWxwOkF1dGhuUmVxdWVzdCB4bWxuczpzYW1scD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOnByb3RvY29sIiB4bWxuczpkc2lnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwLzA5L3htbGRzaWcjIiB4bWxuczplbmM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvMDQveG1sZW5jIyIgeG1sbnM6c2FtbD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFzc2VydGlvbiIgeG1sbnM6eDUwMD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOnByb2ZpbGVzOmF0dHJpYnV0ZTpYNTAwIiB4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIiBEZXN0aW5hdGlvbj0iaHR0cHM6Ly9maWRvLmV4YW1wbGUuY29tL2ZpZG9zZXJ2ZXIvbG9naW4uanNwIiBJRD0iaWQtV0MybGhkaHJUR21XNWRkZkJ3aEFqNUtmd25jLSIgSXNzdWVJbnN0YW50PSIyMDE2LTA3LTE0VDAwOjI2OjA1WiIgVmVyc2lvbj0iMi4wIj48c2FtbDpJc3N1ZXIgRm9ybWF0PSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6bmFtZWlkLWZvcm1hdDplbnRpdHkiPmh0dHA6Ly9kZW4wMGFjbS51cy5vcmFjbGUuY29tOjg5OTAvZmVkL1RFTkFOVDE8L3NhbWw6SXNzdWVyPjxkc2lnOlNpZ25hdHVyZT48ZHNpZzpTaWduZWRJbmZvPjxkc2lnOkNhbm9uaWNhbGl6YXRpb25NZXRob2QgQWxnb3JpdGhtPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzEwL3htbC1leGMtYzE0biMiLz48ZHNpZzpTaWduYXR1cmVNZXRob2QgQWxnb3JpdGhtPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwLzA5L3htbGRzaWcjcnNhLXNoYTEiLz48ZHNpZzpSZWZlcmVuY2UgVVJJPSIjaWQtV0MybGhkaHJUR21XNWRkZkJ3aEFqNUtmd25jLSI+PGRzaWc6VHJhbnNmb3Jtcz48ZHNpZzpUcmFuc2Zvcm0gQWxnb3JpdGhtPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwLzA5L3htbGRzaWcjZW52ZWxvcGVkLXNpZ25hdHVyZSIvPjxkc2lnOlRyYW5zZm9ybSBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvMTAveG1sLWV4Yy1jMTRuIyIvPjwvZHNpZzpUcmFuc2Zvcm1zPjxkc2lnOkRpZ2VzdE1ldGhvZCBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvMDkveG1sZHNpZyNzaGExIi8+PGRzaWc6RGlnZXN0VmFsdWU+NGZpbzdPSzc4YkdQc1Vtc2hLSE5TNUl3eVhFPTwvZHNpZzpEaWdlc3RWYWx1ZT48L2RzaWc6UmVmZXJlbmNlPjwvZHNpZzpTaWduZWRJbmZvPjxkc2lnOlNpZ25hdHVyZVZhbHVlPmhlUjZuZXkvNGNxOEtqaFg1VXg5L0R6Y3BnZDZQcEVKZzRnVHQyckp5NFZObGk0SEpwZjVZYjN4Mk9RdWIveG1vNy83RVNqeTBZaWZiVnc3QmY2THRtUTdMNWdaTDNPUkRIR1J3a3Y5SWwrRWZuK2hFK05lYndQOTdLOWI0TnlPbjRYTC9GSG9BT1V1eW1YT2hrOTJQM3R2akVCZDg3cERYaG1CWU5vc1BIRT08L2RzaWc6U2lnbmF0dXJlVmFsdWU+PGRzaWc6S2V5SW5mbz48ZHNpZzpYNTA5RGF0YT48ZHNpZzpYNTA5Q2VydGlmaWNhdGU+TUlJQ1VEQ0NBYm1nQXdJQkFnSUVMZkdjWERBTkJna3Foa2lHOXcwQkFRVUZBREJYTVJNd0VRWUtDWkltaVpQeUxHUUJHUllEWTI5dE1SWXdGQVlLQ1pJbWlaUHlMR1FCR1JZR2IzSmhZMnhsTVJVd0V3WUtDWkltaVpQeUxHUUJHUllGWTJ4dmRXUXhFVEFQQmdOVkJBTVRDRU5zYjNWa09VTkJNQjRYRFRFMU1URXlNREE1TXpJME9Gb1hEVEkxTVRFeE56QTVNekkwT0Zvd1h6RVRNQkVHQ2dtU0pvbVQ4aXhrQVJrV0EyTnZiVEVXTUJRR0NnbVNKb21UOGl4a0FSa1dCbTl5WVdOc1pURVZNQk1HQ2dtU0pvbVQ4aXhrQVJrV0JXTnNiM1ZrTVJrd0Z3WURWUVFEREJCdmNtTnNUVlF4TWpNeU16SmZhV1J0TUlHZk1BMEdDU3FHU0liM0RRRUJBUVVBQTRHTkFEQ0JpUUtCZ1FDTFZ2eXVlK3FGcmF4d001THhhTkx0MlFIM3dIbi9uMCt5azJqbVA3bXBZa3oxeHJLdUVrMmUyU0NnZ3pLOE1UOWpKNVZVYU5sRjBNd2hJWjgvbmF4QTVMUEN6R0VWZlovNDFHUHRHTkFERnlzcHFHSGtkc052K00yZUNCbWU3TURwOUwzbm9CdHQycGVxR3F4U3UwREh5dDF3Z05yNnA2RVhxVFQ0QWJMZHlRSURBUUFCb3lFd0h6QWRCZ05WSFE0RUZnUVUycnRvZ0hLQzAvd3MyZFMzWnE3czl3d01vZmt3RFFZSktvWklodmNOQVFFRkJRQURnWUVBSzFqdGNiUnBZRkFsMkJwOVgwMk1hQS9pZ3EzV1h5a2l6SDd1UXZyV2dOUWx1ZjdBRGJ4YUI3Sjk2amFJTjJHTFFGeGw2Y2JQd092Qkl1N3hkOWEyNmVLNkY1Z3E0aUpLbTdHZU9nVjVQWjRyNXVtdlNaZ0EwYUxPQWJoWi9nd3k0MFJhdUYwWCs0STdKcWFtblYwRGl6TTJZRURzRldLZlRTdkN5OTBaaXpNPTwvZHNpZzpYNTA5Q2VydGlmaWNhdGU+PC9kc2lnOlg1MDlEYXRhPjwvZHNpZzpLZXlJbmZvPjwvZHNpZzpTaWduYXR1cmU+PHNhbWxwOk5hbWVJRFBvbGljeSBBbGxvd0NyZWF0ZT0idHJ1ZSIgRm9ybWF0PSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoxLjE6bmFtZWlkLWZvcm1hdDplbWFpbEFkZHJlc3MiLz48L3NhbWxwOkF1dGhuUmVxdWVzdD4=");
    }

    public void signSAMLObject(Element target) {
        try {
            Reference ref = factory.newReference("#" + target.getAttribute("ID"),
                    factory.newDigestMethod(DigestMethod.SHA1, null),
                    Collections.singletonList(factory.newTransform(Transform.ENVELOPED, (TransformParameterSpec) null)),
                    null,
                    null);
            SignedInfo signedInfo = factory.newSignedInfo(factory.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE,
                    (C14NMethodParameterSpec) null),
                    factory.newSignatureMethod(SignatureMethod.RSA_SHA1, null),
                    Collections.singletonList(ref));
            xmlSignature = factory.newXMLSignature(signedInfo, keyInfo);
            DOMSignContext signContext = new DOMSignContext(pkEntry.getPrivateKey(), target);
            xmlSignature.sign(signContext);

            Node signatureElement = target.getLastChild();

            boolean foundIssuer = false;
            Node elementAfterIssuer = null;
            NodeList children = target.getChildNodes();
            for (int c = 0; c < children.getLength(); ++c) {
                Node child = children.item(c);

                if (foundIssuer) {
                    elementAfterIssuer = child;
                    break;
                }

                if (child.getNodeType() == Node.ELEMENT_NODE
                        && child.getLocalName().equals("Issuer")) {
                    foundIssuer = true;
                }
            }

            // Place after the Issuer, or as first element if no Issuer:
            if (!foundIssuer || elementAfterIssuer != null) {
                target.removeChild(signatureElement);
                target.insertBefore(signatureElement,
                        foundIssuer
                                ? elementAfterIssuer
                                : target.getFirstChild());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public String getSAMLAssertion(String username, String samlRequestID) {

        System.setProperty("org.apache.xml.security.ignoreLineBreaks", "true");
        System.setProperty("org.apache.xml.security.util.XMLUtils.ignoreAddReturnToElement", "true");

        XMLObjectBuilderFactory builderFactory = Configuration.getBuilderFactory();
        initializeSigning();

        DateTime now = new DateTime();
        Issuer issuer = create(Issuer.class, Issuer.DEFAULT_ELEMENT_NAME);
        issuer.setValue(IDPConfiguration.getIdpConfiguration().getProperty("SAMLIssuer"));
        issuer.setFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:entity");

        NameID nameID = create(NameID.class, NameID.DEFAULT_ELEMENT_NAME);
        nameID.setFormat("urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress");
        nameID.setValue(username);

        Subject subject = create(Subject.class, Subject.DEFAULT_ELEMENT_NAME);
        subject.setNameID(nameID);

        SubjectConfirmationBuilder subjectConfirmationBuilder = (SubjectConfirmationBuilder) builderFactory
                .getBuilder(SubjectConfirmation.DEFAULT_ELEMENT_NAME);
        //SubjectConfirmationBuilder subjectConfirmationBuilder = create(SubjectConfirmationBuilder.class, SubjectConfirmation.DEFAULT_ELEMENT_NAME);
        SubjectConfirmation subjectConfirmation = subjectConfirmationBuilder.buildObject();
        subjectConfirmation.setMethod("urn:oasis:names:tc:SAML:2.0:cm:bearer");

        SubjectConfirmationDataBuilder subjectConfirmationDataBuilder = (SubjectConfirmationDataBuilder) builderFactory
                .getBuilder(SubjectConfirmationData.DEFAULT_ELEMENT_NAME);
        //SubjectConfirmationDataBuilder subjectConfirmationDataBuilder = create(SubjectConfirmationDataBuilder.class,SubjectConfirmationData.DEFAULT_ELEMENT_NAME);
        SubjectConfirmationData subjectConfirmationData = subjectConfirmationDataBuilder.buildObject();
        //subjectConfirmationData.getUnknownXMLObjects().add(peerKeyInfo);
        //subjectConfirmationData.setInResponseTo("http://tenant1.idcs.internal.oracle.com:8990/fed/v1/sp/sso");
        subjectConfirmationData.setRecipient(IDPConfiguration.getIdpConfiguration().getProperty("SAMLRecipient"));
        subjectConfirmationData.setNotOnOrAfter(now.plusSeconds(3600));
        if (samlRequestID != null) {
            subjectConfirmationData.setInResponseTo(samlRequestID);
        }
        subjectConfirmation.setSubjectConfirmationData(subjectConfirmationData);
        subject.getSubjectConfirmations().add(subjectConfirmation);

        Conditions conditions = create(Conditions.class, Conditions.DEFAULT_ELEMENT_NAME);
        conditions.setNotBefore(now.minusSeconds(15));
        conditions.setNotOnOrAfter(now.plusSeconds(3600));

        AudienceRestrictionBuilder audienceRestrictionBuilder = (AudienceRestrictionBuilder) builderFactory
                .getBuilder(AudienceRestriction.DEFAULT_ELEMENT_NAME);
        AudienceRestriction audienceRestriction = audienceRestrictionBuilder.buildObject();
        AudienceBuilder audienceBuilder = (AudienceBuilder) builderFactory
                .getBuilder(Audience.DEFAULT_ELEMENT_NAME);
        Audience e = audienceBuilder.buildObject();
        e.setAudienceURI(IDPConfiguration.getIdpConfiguration().getProperty("SAMLAudience"));
        audienceRestriction.getAudiences().add(e);
        conditions.getAudienceRestrictions().add(audienceRestriction);

        AuthnContextClassRef ref = create(AuthnContextClassRef.class,
                AuthnContextClassRef.DEFAULT_ELEMENT_NAME);
        ref.setAuthnContextClassRef(AuthnContext.PPT_AUTHN_CTX);

        AuthnContext authnContext = create(AuthnContext.class, AuthnContext.DEFAULT_ELEMENT_NAME);
        authnContext.setAuthnContextClassRef(ref);

        AuthnStatement authnStatement = create(AuthnStatement.class, AuthnStatement.DEFAULT_ELEMENT_NAME);
        authnStatement.setAuthnInstant(now);
        authnStatement.setSessionNotOnOrAfter(now.plusSeconds(3600));
        authnStatement.setAuthnContext(authnContext);

        Assertion assertion
                = create(Assertion.class, Assertion.DEFAULT_ELEMENT_NAME);
        RandomIdentifierGenerator idGenerator = new RandomIdentifierGenerator();
        String assertionId = "id-" + U2fB64Encoding.encode(idGenerator.generateIdentifier().getBytes());
        String responseId = "id-" + U2fB64Encoding.encode(idGenerator.generateIdentifier().getBytes());
        assertion.setID(assertionId);
        assertion.setIssueInstant(now);
        assertion.setSchemaLocation("http://www.w3.org/2001/XMLSchema-instance");
        assertion.setIssuer(issuer);
        assertion.setSubject(subject);
        assertion.getStatements().add(authnStatement);
        assertion.setSignature(signature);
        assertion.setConditions(conditions);

        StatusCode samlStatusCode = create(StatusCode.class, StatusCode.DEFAULT_ELEMENT_NAME);
        samlStatusCode.setValue("urn:oasis:names:tc:SAML:2.0:status:Success");

        Status samlStatus = create(Status.class, Status.DEFAULT_ELEMENT_NAME);
        samlStatus.setStatusCode(samlStatusCode);

        Issuer responseIssuer = create(Issuer.class, Issuer.DEFAULT_ELEMENT_NAME);
        responseIssuer.setValue(IDPConfiguration.getIdpConfiguration().getProperty("SAMLIssuer"));
        responseIssuer.setFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:entity");

        Response samlResponse = create(Response.class, Response.DEFAULT_ELEMENT_NAME);
        samlResponse.setDestination(IDPConfiguration.getIdpConfiguration().getProperty("SAMLRecipient"));
        samlResponse.setID(responseId);
        samlResponse.setIssueInstant(now);
        samlResponse.setStatus(samlStatus);
        samlResponse.setIssuer(responseIssuer);
        samlResponse.getAssertions().add(assertion);
        if (samlRequestID != null) {
            samlResponse.setInResponseTo(samlRequestID);
        }

        AssertionMarshaller marshaller = new AssertionMarshaller();
        try {
            marshaller.marshall(assertion);
        } catch (MarshallingException me) {
            me.printStackTrace();
        }
        try {
            Signer.signObject(signature);
        } catch (SignatureException se) {
            se.printStackTrace();
        }
        //assertion.setSignature(signature);

        Document samlDocument = null;
        try {
            samlDocument = asDOMDocument(samlResponse);
        } catch (TransformerException te) {
            te.printStackTrace();
        } catch (MarshallingException me) {
            me.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

        String returningAssertion = null;
        returningAssertion = convertToString(samlDocument);

        return returningAssertion;
    }

    private String convertToString(Document samlDocument) {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        String assertion = null;
        try {
            TransformerFactory.newInstance().newTransformer()
                    .transform(new DOMSource(samlDocument), new StreamResult(buffer));

            byte[] rawResult = buffer.toByteArray();
            buffer.close();
            assertion = new String(rawResult);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return assertion;
    }

    private String removeSpaces(String assertion) {
        return assertion;
    }
}
