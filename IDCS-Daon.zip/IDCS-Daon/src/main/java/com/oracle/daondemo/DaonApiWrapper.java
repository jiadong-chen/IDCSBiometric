/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oracle.daondemo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.Proxy;
import java.net.InetSocketAddress;
import java.io.OutputStreamWriter;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author krmanchi
 */



public class DaonApiWrapper {

    public static String verifyDaon(String email) throws Exception{
      try {
        String url = "https://api.identityx-cloud.com/oracleapimarketplace/IdentityXServices/rest/v1/users?userId=" + email + "&status=ACTIVE&limit=1";
        URL obj = new URL(url);
        HttpURLConnection conn = (HttpURLConnection) obj.openConnection();

        conn.setRequestMethod("GET");
        String userpass = "jiadong.chen@oracle.com" + ":" + "WelcomeOracle123";
        String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes("UTF-8"));
        conn.setRequestProperty("Authorization", basicAuth);
        conn.connect();


        BufferedReader in  = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);}
        in.close();
        JSONObject myResponse = new JSONObject(response.toString());
        JSONArray items = myResponse.getJSONArray("items");
        //JSONObject items = myResponse.getJSONObject("items");
        //print in String
        System.out.println(response.toString());
        System.out.println("-----------");
        System.out.println(myResponse);
        System.out.println("-----------");
        System.out.println(items.getJSONObject(0).getString("href"));//need to change
        String tenantURL = items.getJSONObject(0).getString("href");
        return tenantURL;
    }
        catch (Exception e) {
            e.printStackTrace();

            throw e;
        }


    }

    public static String startAuthn(String username, String tenantID) throws Exception {
        try {
            String url = "https://api.identityx-cloud.com/oracleapimarketplace/IdentityXServices/rest/v1/authenticationRequests";

            URL obj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();

            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            conn.setRequestMethod("POST");
            String uuid = UUID.randomUUID().toString().replace("-", "");
            String userpass = "jiadong.chen@oracle.com" + ":" + "WelcomeOracle123";
            String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes("UTF-8"));
            conn.setRequestProperty("Authorization", basicAuth);
            String data = "{\n"
                    + "    \"type\" : \"IX\",\n"
                    + "    \"description\" : \"Authentication Request Test\",\n"
                    + "    \"authenticationRequestId\" : \"" + uuid + "\"\n"
                    + "                ,\n"
                    + "    \"oneTimePasswordEnabled\" : false,\n"
                    + "    \"user\": {\n"
                    + "        \"href\"\n"
                    + "                : \"" + tenantID + "\"\n"
                    + "    },\n"
                    + "    \"application\":\n"
                    + "                {\n"
                    + "                    \"href\"\n"
                    + "                : \"https://api.identityx-cloud.com/oracleapimarketplace/IdentityXServices/rest/v1/applications/QTAz9OKsfyKXFdmdtx430-vgaw\"\n"
                    + "    },\n"
                    + "    \"tenant\":\n"
                    + "                {\n"
                    + "                    \"href\"\n"
                    + "                : \"https://api.identityx-cloud.com/IdentityXServices/rest/v1/tenants/wxY5Rti2UkzLZKLpCYAiJA\"\n"
                    + "    },\n"
                    + "    \"policy\" :\n"
                    + "                {\n"
                    + "                    \"href\"\n"
                    + "                : \"https://api.identityx-cloud.com/oracleapimarketplace/IdentityXServices/rest/v1/policies/QTAz6T30PwbdOg_MkiGeswhF9A\"\n"
                //    + "    }\n"
                 //   + "    \"pushNotificationType\" : \"VERIFY_WITH_CONFIRMATION\"\n"
                    + "            }\n}";

            System.out.println("JAVA JSON:" + data);


            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
            out.write(data);



            out.close();

            BufferedReader in  = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            
//            BufferedReader in = null;
//
//                if(conn.getResponseCode() == 200)
//                    {
//                    in = new BufferedReader(new
//                    InputStreamReader(conn.getInputStream()));
//                    }
//                else
//                    {
//                    in = new BufferedReader(new
//                    InputStreamReader(conn.getErrorStream()));
//                    }

            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);}
            in.close();
            JSONObject myResponse = new JSONObject(response.toString());
            //print in String
            System.out.println(response.toString());
            System.out.println("-----------");
            System.out.println("Response id now:"+ myResponse.getString("id"));

            // TODO: extract ID from HTTP response


            return myResponse.getString("id");

        } catch (Exception e) {
            e.printStackTrace();

            throw e;
        }
    }

    public static Boolean pollAuthn(String requestID) throws Exception {
        try {

            String url = "https://api.identityx-cloud.com/oracleapimarketplace/IdentityXServices/rest/v1/authenticationRequests/" + requestID;

            URL obj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();

            conn.setRequestMethod("GET");
            String userpass = "jiadong.chen@oracle.com" + ":" + "WelcomeOracle123";
            String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes("UTF-8"));
            conn.setRequestProperty("Authorization", basicAuth);

//            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
//            System.out.print(out);
//            out.close();
            conn.connect();


            BufferedReader in  = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);}
            in.close();
            JSONObject myResponse = new JSONObject(response.toString());
            //print in String
            System.out.println(response.toString());
            System.out.println("-----------");
            System.out.println(myResponse.getString("status"));
            String status = myResponse.getString("status");
            if (( status != null ) &&
                ( status.equals("COMPLETED_SUCCESSFUL") ) ) {
                return true;
            }
            else{
                return false;
            }


        } catch (Exception e) {
            e.printStackTrace();

            throw e;
        }
    }
}